<?php

namespace App\Http\Controllers\Modules;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ForecastController extends Controller
{

    public function weather()
    {
        return view('pages.forecast');
    }




    public function getDataFromApi(Request $request)
    {
        $response = Http::get("https://api.openweathermap.org/data/3.0/onecall?lat=33.44&lon=-94.04&exclude=hourly,daily&appid=146ce1108bd9aed794bd2078a5764f0f");
        return $response;
    }
}
