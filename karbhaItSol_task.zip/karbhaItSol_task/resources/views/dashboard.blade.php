@extends('layout')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('success'))
                    <div class="alert alert-success" role="alert">
                        {{ session('success') }}
                    </div>
                    @endif

                    You are Logged In


                    <div class="row">
                        <div class="col-sm-12">
                            <div class="row">

                                <div class=" col-sm-2 d-flex float-left">
                                    <div class="mr-2">
                                        <a class="btn ripple btn-primary" href="{{route('weather')}}">
                                            <i class="fas fa-step-backward"></i> Map View</a>
                                    </div>
                                </div>
                            </div>
                            <h1>MAP VIEW </h1>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection