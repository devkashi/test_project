

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>

                    You are Logged In


                    <div class="row">
                        <div class="col-sm-12">
                            <div class="row">

                                <div class=" col-sm-2 d-flex float-left">
                                    <div class="mr-2">
                                        <a class="btn ripple btn-primary" href="<?php echo e(route('weather')); ?>">
                                            <i class="fas fa-step-backward"></i> Map View</a>
                                    </div>
                                </div>
                            </div>
                            <h1>MAP VIEW </h1>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\assignment\KASHISH\resources\views/dashboard.blade.php ENDPATH**/ ?>